ACMEJOB.Ai BRAND KIT
====================
SEIS 201: AI for CE/ME Engineers — University of St. Thomas

Everything you hand in this semester goes on ACMEJOB.Ai letterhead. This kit is
how. Start here.

FIRST, INSTALL THE FONTS
  Open fonts/ and install all sixteen .ttf files (select all, right-click,
  Install — or drag them into Font Book on a Mac). Do this before you open the
  templates, or your documents will silently substitute Arial and the spacing
  will shift.

THEN READ
  ACMEJOB-brand-guide.docx      Two pages. Colour, type, voice, logo rules.

THE TEMPLATES
  ACMEJOB-memo-template.docx    Memos, notes, short reports.
  ACMEJOB-deck-template.pptx    Presentations, including the May county briefing.
  ACMEJOB-calculation-sheet.xlsx  Any calculation somebody else has to check.

  Save a copy before you edit. Do not work in the original.

LOGO FILES  (logo/)
  Use .svg wherever it will scale. Use .png in Word and PowerPoint.
  acmejob-logo-horizontal    Document headers. The one you will use most.
  acmejob-logo-primary       Covers and title slides.
  acmejob-logo-stacked       Square or narrow spaces.
  acmejob-mark               The bridge alone.
  foreman-mark               Label FOREMAN output as FOREMAN output. Always.
  kinnick-county-seal        County documents only. Never on our letterhead.
  Anything ending -dark is for dark backgrounds.

THE ONE RULE
  Orange means a machine said it. Blue means a person said it.
  Keep that straight and your reader never has to ask.

FONT LICENCES
  Barlow, Barlow Condensed, Caveat and IBM Plex Mono are all licensed under the
  SIL Open Font License 1.1. The licence text is in fonts/. You may install and
  use them freely, including in work you hand in and work you publish.

ACMEJOB.Ai, FOREMAN, the Otter Bend Lift Bridge and Kinnick County are fictional,
invented for this course. Any resemblance to a real firm, product or structure is
coincidental.
